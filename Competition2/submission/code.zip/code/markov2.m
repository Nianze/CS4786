sample = csvread('\data\sample.csv');
data = xlsread('\data\fillindata.csv');


count = zeros(5,5,5);
for i = 1:1000
    for j = 1:98
        if(~isnan(data(i,j)) && ~isnan(data(i,j+1)) && ~isnan(data(i,j+2)))
            count(data(i,j),data(i,j+1),data(i,j+2)) = count(data(i,j),data(i,j+1),data(i,j+2)) + 1;
        end
    end
end

prob1 = zeros(5,5,5)
for i = 1:5
    for j = 1:5
        if sum(count(i,j,:)) ~=0
            prob1(i,j,:) = count(i,j,:)/sum(count(i,j,:));
        end
    end
end


prob2 = zeros(5,5,5)
for i = 1:5
    for j = 1:5
        if sum(count(i,:,j)) ~=0
            prob2(i,:,j) = count(i,:,j)/sum(count(i,:,j));
        end
    end
end


prob3 = zeros(5,5,5)
for i = 1:5
    for j = 1:5
        if sum(count(:,i,j)) ~=0
            prob3(:,i,j) = count(:,i,j)/sum(count(:,i,j));
        end
    end
end

likelihood = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                for m = 1:5
                    likelihood(i,j,k,l,m) = prob1(i,j,k)*prob2(j,k,l)*prob3(k,l,m);
                end
            end
        end
    end
end


maxllh = zeros(5,5,5,5);

for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                maxllh(i,j,k,l) = find(likelihood(i,j,:,k,l) == max(likelihood(i,j,:,k,l)),1);
            end
        end
    end
end

missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data));



firstHead_count = zeros(5,5,5);
for i = 1:1000
    if(~isnan(data(i,1)) && ~isnan(data(i,2)) && ~isnan(data(i,3)))
        firstHead_count(data(i,1),data(i,2),data(i,3)) = firstHead_count(data(i,1),data(i,2),data(i,3))+1;
    end
end


firstHead = [];
for i = 1:5
    for j = 1:5
        firstHead(i,j)  = find(firstHead_count(:,i,j) == max(firstHead_count(:,i,j)),1);
    end
end


secondHead_count = zeros(5,5,5,5);
for i = 1:1000
    if(~isnan(data(i,1)) && ~isnan(data(i,2)) && ~isnan(data(i,3)) && ~isnan(data(i,4)))
        secondHead_count(data(i,1),data(i,2),data(i,3),data(i,4)) = secondHead_count(data(i,1),data(i,2),data(i,3),data(i,4))+1;
    end
end


secondHead = [];
for i = 1:5
    for j = 1:5
        for k = 1:5
            secondHead(i,j,k)  = find(secondHead_count(i,:,j,k) == max(secondHead_count(i,:,j,k)),1);
        end
    end
end


last_count = zeros(5,5,5);
for i = 1:1000
    if(~isnan(data(i,98)) && ~isnan(data(i,99)) && ~isnan(data(i,100)))
        last_count(data(i,98),data(i,99),data(i,100)) = last_count(data(i,98),data(i,99),data(i,100))+1;
    end
end


last = [];
for i = 1:5
    for j = 1:5
        last(i,j)  = find(last_count(i,j,:) == max(last_count(i,j,:)),1);
    end
end


secondLast_count = zeros(5,5,5,5);
for i = 1:1000
    if(~isnan(data(i,97)) && ~isnan(data(i,98)) && ~isnan(data(i,99)) && ~isnan(data(i,100)))
        secondLast_count(data(i,97),data(i,98),data(i,99),data(i,100)) = secondLast_count(data(i,97),data(i,98),data(i,99),data(i,100))+1;
    end
end


secondLast = [];
for i = 1:5
    for j = 1:5
        for k = 1:5
            secondLast(i,j,k)  = find(secondLast_count(i,j,:,k) == max(secondLast_count(i,j,:,k)),1);
        end
    end
end



missing_num = length(missing_ind);

result = zeros(missing_num,1);
for i = 1:missing_num
    i
    temp_2before = 0;
    temp_1before = 0;
    temp_1after = 0;
    temp_2after = 0;
    if missing_ind(i,2) == 1
        1
        temp_1after = data(missing_ind(i,1),2);
        temp_2after = data(missing_ind(i,1),3);
        result(i) = firstHead(temp_1after, temp_2after);
    else if missing_ind(i,2) == 2
            2
            temp_1before = data(missing_ind(i,1),1);
            temp_1after = data(missing_ind(i,1),3);
            temp_2after = data(missing_ind(i,1),4);
            result(i) = secondHead(temp_1before, temp_1after, temp_2after);
        else if missing_ind(i,2) == 99
                3
                temp_2before = data(missing_ind(i,1),97);
                temp_1before = data(missing_ind(i,1),98);
                temp_1after = data(missing_ind(i,1),100);
                result(i) = secondLast(temp_2before, temp_1before, temp_1after);
            else if missing_ind(i,2) == 100
                    4
                    temp_2before = data(missing_ind(i,1),98);
                    temp_1before = data(missing_ind(i,1),99);
                    result(i) = last(temp_2before, temp_1before);
                else
                    5
                    temp_2before = data(missing_ind(i,1),missing_ind(i,2)-2);
                    temp_1before = data(missing_ind(i,1),missing_ind(i,2)-1);
                    temp_1after = data(missing_ind(i,1),missing_ind(i,2)+1);
                    temp_2after = data(missing_ind(i,1),missing_ind(i,2)+2);
                    result(i) = maxllh(temp_2before, temp_1before,temp_1after, temp_2after);
                end
            end
        end
    end
end




answer(:,1) = 101:1000;
answer(:,2) = zeros(900,1)
for i = 1:missing_num
    answer(missing_ind(i,1)-100,2) = result(i);
end

csvwrite('answer.csv',answer);