
clear all
data_full=xlsread('fillindata.xls');
data=data_full(1:100,:);

%% find the mising index
missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data_full));
missing_num = length(missing_ind);
    

T=4;

R=zeros(900,T); % T is the trial, we want to compare the missing value from the state of 7 to 10
%% predict the missing value with multiple simulation under various states
for t=1:T
    
    O=5;
    Nstate=6+T;
    prior1 = normalise(rand(Nstate,1));
    transmat1 = mk_stochastic(rand(Nstate,Nstate));
    obsmat1 = mk_stochastic(rand(Nstate,O));
    [LL, prior2, transmat2, obsmat2]=dhmm_em(data, prior1, transmat1, obsmat1,'max_iter', 100);

   
    result = zeros(missing_num,2);

    LKH=zeros(900,5);
    index=zeros(900,2);

    for i=1:900
        for mis=1:5

            data_full(missing_ind(i,1),missing_ind(i,2))=mis;
            LKH(missing_ind(i,1),mis)=dhmm_logprob(data_full(missing_ind(i),:), prior2, transmat2, obsmat2);

        end
            [index(i,1),index(i,2)]=max(LKH(missing_ind(i,1),:));
            result(missing_ind(i,1)-100,2)=index(i,2);
    end

    R(:,t)=result(:,2);

end

result(:,1)=101:1000;
[result(:,2),fre] = mode(R,2); % select the state with most frequency under multiple simulation 

sum(fre==4)
sum(fre==3)
sum(fre==2)

csvwrite('stateavg.csv',result);






    