﻿README


1. HMM matlab (use HMMall package) https://www.cs.ubc.ca/~murphyk/Software/HMM/hmm.html


HMM_stateSelect: use training data to train and validate state selection
HMM_modelTest: Test the proposed model with training data
HMM_prediction: Predict with missing value in remaining 900 lines with multiple simulations
HMM_fixReverse: Predict the missing value with consideration of reverse sequence
HMM_messageP: Predict the missing value with the idea of message pass.


2. HMM in python
[HMM.py]: Given the 100 observed sequence to estimate the model parameters and predict the missing value with consideration of the reverse sequence
[parameter]: n_components=8, n_iter=1000
[package]: hmmlearn.hmm(https://github.com/hmmlearn/hmmlearn) and numpy


3. Simple Markov Model
File: markov2.m
Data: sample.csv (first 100 rows of fillindata.csv)
Assumed each observation is dependent on its 2 observation before it. Using conditional probabilities and maximum likelihood to estimate missing observation. 
Output a csv file without header.