clear all
data_full=xlsread('fillindata.xls');
data=data_full(1:100,:);
%% deal with the 5% reverse seq
O=5;
Nstate=7;
prior1 = normalise(rand(Nstate,1));
transmat1 = mk_stochastic(rand(Nstate,Nstate));
obsmat1 = mk_stochastic(rand(Nstate,O));
[LL, prior2, transmat2, obsmat2]=dhmm_em(data, prior1, transmat1, obsmat1,'max_iter', 100);

% find the mising index
missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data_full));
missing_num = length(missing_ind);
result = zeros(missing_num,2);
result(:,1)=101:1000;

LKH=zeros(1000,5);
LKH1=zeros(1000,5);
LKH2=zeros(1000,5);
index=zeros(900,2);
reverse=zeros(900,100);
for i=1:900
    for mis=1:5
        
        data_full(missing_ind(i,1),missing_ind(i,2))=mis;
        LKH1(missing_ind(i,1),mis)=dhmm_logprob(data_full(missing_ind(i),:), prior2, transmat2, obsmat2);
        reverse(i,:)=fliplr(data_full(missing_ind(i),:));
        LKH2(missing_ind(i,1),mis)=dhmm_logprob(reverse(i,:), prior2, transmat2, obsmat2);
        LKH=[LKH1,LKH2];
        [index(i,1),index(i,2)]=max(LKH(missing_ind(i,1),:));
        
        result(missing_ind(i,1)-100,2)=index(i,2);
        
    end
end



csvwrite('result_state7_reverse.csv',result);