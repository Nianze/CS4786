clear all
data_full=xlsread('fillindata.xls');
data=data_full(1:100,:);
%%
O=5;
Nstate=7;
prior1 = normalise(rand(Nstate,1));
transmat1 = mk_stochastic(rand(Nstate,Nstate));
obsmat1 = mk_stochastic(rand(Nstate,O));
[LL, prior2, transmat2, obsmat2]=dhmm_em(data, prior1, transmat1, obsmat1,'max_iter', 100);

%% find the mising index
missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data_full));
missing_num = length(missing_ind);

%% find the missing value with message passing idea
seq_af=[];
seq_bef=[];
state_af=zeros(900,1);
state_bf=zeros(900,1);
% state is ranged by missing index
for i=1:missing_num
    if missing_ind(i,2)==1
        seq_af=data_full(missing_ind(i,1),missing_ind(i,2)+1:end);
        B = multinomial_prob(seq_af, obsmat2);
        [path] = viterbi_path(prior2, transmat2, B);
        state_af(i)=path(1);
        
    elseif missing_ind(i,2)==100
        seq_bef=data_full(missing_ind(i,1),1:missing_ind(i,2)-1);
        B = multinomial_prob(seq_bef, obsmat2);
        [path] = viterbi_path(prior2, transmat2, B);        
        state_bf(i)=path(end);
    else 
        seq_af=data_full(missing_ind(i,1),missing_ind(i,2)+1:end);
        B1 = multinomial_prob(seq_af, obsmat2);
        [path1] = viterbi_path(prior2, transmat2, B1); 
        seq_bef=data_full(missing_ind(i,1),1:missing_ind(i,2)-1);
        B2 = multinomial_prob(seq_bef, obsmat2);
        [path2] = viterbi_path(prior2, transmat2, B2);       
        state_af(i)=path1(1);
        state_bf(i)=path2(end);
    end
end

lik=zeros(900,5);

for i=1:900
    
    if state_bf(i)==0
        for x=1:5
            for s=1:Nstate
                lik(i,x)=lik(i,x)+transmat2(s,state_af(i))*obsmat2(s,x);
            end
        end
    elseif state_af(i)==0
        for x=1:5
            for s=1:Nstate
                lik(i,x)=lik(i,x)+transmat2(state_bf(i),s)*obsmat2(s,x);
            end
        end
    else
        for x=1:5
            for s=1:Nstate
                lik(i,x)=lik(i,x)+transmat2(state_bf(i),s)*obsmat2(s,x)*transmat2(s,state_af(i));
            end
        end
    end
        
end
% lik is by missing_inx
result=zeros(900,2);
result(:,1)=101:1000;

value=zeros(900,1);
for i=1:900
    [value(i),result(missing_ind(i,1)-100,2)]= max(lik(i,:));
end

csvwrite('result_messageP_pac.csv',result);