
clear all
data_full=xlsread('fillindata.xls');
data=data_full(1:100,:);
%% training train; the model under training data
O=5;
Nstate=8;
max_iter=100;
loglik=zeros(Nstate,1);

for Q=1:Nstate
    
    % initial guess of parameters
    prior1 = normalise(rand(Q,1));
    transmat1 = mk_stochastic(rand(Q,Q));
    obsmat1 = mk_stochastic(rand(Q,O));
    % improve guess of parameters using EM
    [LL, prior, transmat, obsmat] = dhmm_em(data(1:50,:), prior1, transmat1, obsmat1, 'max_iter', max_iter);
    % use model to compute log likelihood
    loglik(Q) = dhmm_logprob(data(51:80,:), prior, transmat, obsmat);

end

%% validation 

k=zeros(1,Nstate);
AIC=zeros(1,Nstate);
AICC=zeros(1,Nstate);
n=30;
for i=1:Nstate
    k(i)=i-1+i*(i-1)+i*(O-1);
    AIC(i)=2*k(i)-2*loglik(i)/log(30);
    AICC(i)=AIC(i)+2*k(i)*(k(i)+1)/(n-k(i)-1);
end

%% visualization
figure(1);
subplot(1,2,1)
plot(loglik/30)
xlabel('Number of state')
ylabel('loglikelihood of a seq')
title('logLKH of HMM Model with Various Hidden States')
subplot(1,2,2)
plot(AIC)
xlabel('Number of state')
ylabel('AIC')
title('AIC of HMM Model with Various Hidden States')



