sample = csvread('\data\sample.csv');
data = xlsread('\data\fillindata.csv');


count = zeros(5,5);
for i = 1:100
    for j = 1:99
        count(sample(i,j),sample(i,j+1)) = count(sample(i,j),sample(i,j+1)) + 1;
    end
end

prob = zeros(5,5)
for i = 1:5
    prob(i,:) = count(i,:)/sum(count(i,:));
end


likelihood = zeros(5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            likelihood(i,j,k) = prob(i,k)*prob(k,j);
        end
    end
end

maxllh = zeros(5,5);

for i = 1:5
    for j = 1:5
        maxllh(i,j) = find(likelihood(i,j,:) == max(likelihood(i,j,:)));
    end
end

missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data));


ini_count = zeros(5,5);
for i = 1:100
    ini_count(sample(i,1),sample(i,2)) = ini_count(sample(i,1),sample(i,2))+1;
end

ini = [];
for i = 1:5
   ini(i)  = find(ini_count(:,i) == max(ini_count(:,i)),1);
end

last_count = zeros(5,5);
for i = 1:100
    last_count(sample(i,99),sample(i,100)) = last_count(sample(i,99),sample(i,100))+1;
end

last = [];
for i = 1:5
   last(i)  = find(last_count(i,:) == max(last_count(i,:)),1);
end

missing_num = length(missing_ind);

result = zeros(missing_num,1);
for i = 1:missing_num
    temp_before = 0;
    temp_after = 0;
    if missing_ind(i,2) == 1
        temp_after = data(missing_ind(i,1),2);
        result(i) = ini(temp_after);
    else if missing_ind(i,2) == 100
            temp_before = data(missing_ind(i,1),99);
            result(i) = last(temp_before);
        else
            temp_before = data(missing_ind(i,1),missing_ind(i,2)-1);
            temp_after = data(missing_ind(i,1),missing_ind(i,2)+1);
            result(i) = maxllh(temp_before,temp_after);
        end
    end
end

csvwrite('result.csv',result)

answer(:,1) = 101:1000;
answer(:,2) = zeros(900,1)
for i = 1:missing_num
    answer(missing_ind(i,1)-100,2) = result(i);
end

csvwrite('answer.csv',answer);