sample = csvread('\data\sample.csv');
data = xlsread('\data\fillindata.csv');


count = zeros(5,5,5,5,5);
for i = 1:1000
    for j = 1:96
        if(~isnan(data(i,j)) && ~isnan(data(i,j+1)) && ~isnan(data(i,j+2)) && ~isnan(data(i,j+3)) && ~isnan(data(i,j+4)))
            count(data(i,j),data(i,j+1),data(i,j+2),data(i,j+3),data(i,j+4)) = count(data(i,j),data(i,j+1),data(i,j+2),data(i,j+3),data(i,j+4)) + 1;
        end
    end
end

prob1 = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(count(:,i,j,k,l)) ~=0
                    prob1(:,i,j,k,l) = count(:,i,j,k,l)/sum(count(:,i,j,k,l));
                end
            end
        end
    end
end


prob2 = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(count(i,:,j,k,l)) ~=0
                    prob2(i,:,j,k,l) = count(i,:,j,k,l)/sum(count(i,:,j,k,l));
                end
            end
        end
    end
end


prob3 = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(count(i,j,:,k,l)) ~=0
                    prob3(i,j,:,k,l) = count(i,j,:,k,l)/sum(count(i,j,:,k,l));
                end
            end
        end
    end
end

prob4 = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(count(i,j,k,:,l)) ~=0
                    prob4(i,j,k,:,l) = count(i,j,k,:,l)/sum(count(i,j,k,:,l));
                end
            end
        end
    end
end

prob5 = zeros(5,5,5,5,5);
for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(count(i,j,k,l,:)) ~=0
                    prob5(i,j,k,l,:) = count(i,j,k,l,:)/sum(count(i,j,k,l,:));
                end
            end
        end
    end
end

likelihood = zeros(5,5,5,5,5,5,5,5,5);
toend = 5^9
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            for i8 = 1:5
                                for i9 = 1:5
                                    toend = toend - 1
                                    likelihood(i1,i2,i3,i4,i5,i6,i7,i8,i9) = prob5(i1,i2,i3,i4,i5) * prob4(i2,i3,i4,i5,i6) * prob3(i3,i4,i5,i6,i7) * prob2(i4,i5,i6,i7,i8) * prob1(i5,i6,i7,i8,i9);
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end


maxllh = zeros(5,5,5,5,5,5,5,5);

toend = 5^8
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            for i8 = 1:5
                                toend = toend-1
                                maxllh(i1,i2,i3,i4,i5,i6,i7,i8) = find(likelihood(i1,i2,i3,i4,:,i5,i6,i7,i8) == max(likelihood(i1,i2,i3,i4,:,i5,i6,i7,i8)),1);
                            end
                        end
                    end
                end
            end
        end
    end
end



missing_ind = [];
[missing_ind(:,1), missing_ind(:,2)] = find(isnan(data));



head_count = zeros(5,5,5,5,5);
for i = 1:1000
    if(~isnan(data(i,1)) && ~isnan(data(i,2)) && ~isnan(data(i,3)) && ~isnan(data(i,4)) && ~isnan(data(i,5)))
        head_count(data(i,1),data(i,2),data(i,3),data(i,4),data(i,5)) = head_count(data(i,1),data(i,2),data(i,3),data(i,4),data(i,5))+1;
    end
end

head1p = zeros(5,5,5,5,5);
head2p = zeros(5,5,5,5,5);
head3p = zeros(5,5,5,5,5);
head4p = zeros(5,5,5,5,5);

for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(head_count(:,i,j,k,l))~=0
                    head1p(:,i,j,k,l)  = head_count(:,i,j,k,l)/sum(head_count(:,i,j,k,l)) ;
                end
                if sum(head_count(i,:,j,k,l))~=0
                    head2p(i,:,j,k,l)  = head_count(i,:,j,k,l)/sum(head_count(i,:,j,k,l)) ;
                end
                if sum(head_count(i,j,:,k,l))~=0
                    head3p(i,j,k,:,l)  = head_count(i,j,:,k,l)/sum(head_count(i,j,:,k,l)) ;
                end
                if sum(head_count(i,j,k,:,l))~=0
                    head4p(i,j,k,l,:)  = head_count(i,j,k,:,l)/sum(head_count(i,j,k,:,l)) ;
                end
            end
        end
    end
end


head1llh = zeros(5,5,5,5,5);
head2llh = zeros(5,5,5,5,5,5);
head3llh = zeros(5,5,5,5,5,5,5);
head4llh = zeros(5,5,5,5,5,5,5,5);

toend = 5^8
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            for i8 = 1:5
                                toend = toend - 1
                                head1llh(i4,i5,i6,i7,i8) = head1p(i4,i5,i6,i7,i8);
                                head2llh(i3,i4,i5,i6,i7,i8) = head2p(i3,i4,i5,i6,i7) * prob1(i4,i5,i6,i7,i8);
                                head3llh(i2,i3,i4,i5,i6,i7,i8) = head3p(i2,i3,i4,i5,i6) * prob2(i3,i4,i5,i6,i7) * prob1(i4,i5,i6,i7,i8);
                                head4llh(i1,i2,i3,i4,i5,i6,i7,i8) = head4p(i1,i2,i3,i4,i5) * prob3(i2,i3,i4,i5,i6) * prob2(i3,i4,i5,i6,i7) * prob1(i4,i5,i6,i7,i8);
                            end
                        end
                    end
                end
            end
        end
    end
end

head1 = zeros(5,5,5,5);
head2 = zeros(5,5,5,5,5);
head3 = zeros(5,5,5,5,5,5);
head4 = zeros(5,5,5,5,5,5,5);



toend = 5^7
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            toend = toend - 1
                            head1(i4,i5,i6,i7) = find(head1llh(:,i4,i5,i6,i7) == max(head1llh(:,i4,i5,i6,i7)),1 );
                            head2(i3,i4,i5,i6,i7) = find(head2llh(i3,:,i4,i5,i6,i7) == max(head2llh(i3,:,i4,i5,i6,i7)),1 );
                            head3(i2,i3,i4,i5,i6,i7) = find(head3llh(i2,i3,:,i4,i5,i6,i7) == max(head3llh(i2,i3,:,i4,i5,i6,i7)),1);
                            head4(i1,i2,i3,i4,i5,i6,i7) = find(head4llh(i1,i2,i3,:,i4,i5,i6,i7) == max(head4llh(i1,i2,i3,:,i4,i5,i6,i7)),1);
                        end
                    end
                end
            end
        end
    end
end



last_count = zeros(5,5,5);
for i = 1:1000
    if(~isnan(data(i,98)) && ~isnan(data(i,99)) && ~isnan(data(i,100)))
        last_count(data(i,98),data(i,99),data(i,100)) = last_count(data(i,98),data(i,99),data(i,100))+1;
    end
end



tail_count = zeros(5,5,5,5,5);
for i = 1:1000
    if(~isnan(data(i,96)) && ~isnan(data(i,97)) && ~isnan(data(i,98)) && ~isnan(data(i,99)) && ~isnan(data(i,100)))
        tail_count(data(i,96),data(i,97),data(i,98),data(i,99),data(i,100)) = tail_count(data(i,96),data(i,97),data(i,98),data(i,99),data(i,100))+1;
    end
end

tail1p = zeros(5,5,5,5,5);
tail2p = zeros(5,5,5,5,5);
tail3p = zeros(5,5,5,5,5);
tail4p = zeros(5,5,5,5,5);

for i = 1:5
    for j = 1:5
        for k = 1:5
            for l = 1:5
                if sum(tail_count(:,i,j,k,l))~=0
                    tail1p(:,i,j,k,l)  = tail_count(:,i,j,k,l)/sum(tail_count(:,i,j,k,l)) ;
                end
                if sum(tail_count(i,:,j,k,l))~=0
                    tail2p(i,:,j,k,l)  = tail_count(i,:,j,k,l)/sum(tail_count(i,:,j,k,l)) ;
                end
                if sum(tail_count(i,j,:,k,l))~=0
                    tail3p(i,j,k,:,l)  = tail_count(i,j,:,k,l)/sum(tail_count(i,j,:,k,l)) ;
                end
                if sum(tail_count(i,j,k,:,l))~=0
                    tail4p(i,j,k,l,:)  = tail_count(i,j,k,:,l)/sum(tail_count(i,j,k,:,l)) ;
                end
            end
        end
    end
end


tail1llh = zeros(5,5,5,5,5);
tail2llh = zeros(5,5,5,5,5,5);
tail3llh = zeros(5,5,5,5,5,5,5);
tail4llh = zeros(5,5,5,5,5,5,5,5);

toend = 5^8
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            for i8 = 1:5
                                toend = toend - 1
                                tail1llh(i4,i5,i6,i7,i8) = tail1p(i4,i5,i6,i7,i8);
                                tail2llh(i3,i4,i5,i6,i7,i8) = tail2p(i4,i5,i6,i7,i8) * prob5(i3,i4,i5,i6,i7);
                                tail3llh(i2,i3,i4,i5,i6,i7,i8) = tail3p(i4,i5,i6,i7,i8) * prob4(i3,i4,i5,i6,i7) * prob5(i3,i4,i5,i6,i7);
                                tail4llh(i1,i2,i3,i4,i5,i6,i7,i8) = tail4p(i4,i5,i6,i7,i8) * prob3(i1,i2,i3,i4,i5) * prob4(i2,i3,i4,i5,i6) * prob5(i3,i4,i5,i6,i7);
                            end
                        end
                    end
                end
            end
        end
    end
end

tail1 = zeros(5,5,5,5);
tail2 = zeros(5,5,5,5,5);
tail3 = zeros(5,5,5,5,5,5);
tail4 = zeros(5,5,5,5,5,5,5);



toend = 5^7
for i1 = 1:5
    for i2 = 1:5
        for i3 = 1:5
            for i4 = 1:5
                for i5 = 1:5
                    for i6 = 1:5
                        for i7 = 1:5
                            toend = toend - 1
                            %                                 todo next
                            tail1(i4,i5,i6,i7) = find(tail1llh(i4,i5,i6,i7,:) == max(tail1llh(i4,i5,i6,i7,:)),1 );
                            tail2(i3,i4,i5,i6,i7) = find(tail2llh(i3,i4,i5,i6,:,i7) == max(tail2llh(i3,i4,i5,i6,:,i7)),1 );
                            tail3(i2,i3,i4,i5,i6,i7) = find(tail3llh(i2,i3,:,i4,i5,i6,i7) == max(tail3llh(i2,i3,:,i4,i5,i6,i7)),1);
                            tail4(i1,i2,i3,i4,i5,i6,i7) = find(tail4llh(i1,i2,i3,:,i4,i5,i6,i7) == max(tail4llh(i1,i2,i3,:,i4,i5,i6,i7)),1);
                        end
                    end
                end
            end
        end
    end
end



missing_num = length(missing_ind);

result = zeros(missing_num,1);
for i = 1:missing_num
    i
    temp_4before = 0;
    temp_3before = 0;
    temp_2before = 0;
    temp_1before = 0;
    temp_1after = 0;
    temp_2after = 0;
    temp_3after = 0;
    temp_4after = 0;
    if missing_ind(i,2) == 1
        1
        temp_1after = data(missing_ind(i,1),2);
        temp_2after = data(missing_ind(i,1),3);
        temp_3after = data(missing_ind(i,1),4);
        temp_4after = data(missing_ind(i,1),5);
        result(i) = head1(temp_1after, temp_2after,temp_3after, temp_4after);
    else if missing_ind(i,2) == 2
            2
            temp_1before = data(missing_ind(i,1),1);
            temp_1after = data(missing_ind(i,1),3);
            temp_2after = data(missing_ind(i,1),4);
            temp_3after = data(missing_ind(i,1),5);
            temp_4after = data(missing_ind(i,1),6);
            result(i) = head2(temp_1before, temp_1after, temp_2after,temp_3after, temp_4after);
        else if missing_ind(i,2) == 3
                3
                temp_2before = data(missing_ind(i,1),1);
                temp_1before = data(missing_ind(i,1),2);
                temp_1after = data(missing_ind(i,1),4);
                temp_2after = data(missing_ind(i,1),5);
                temp_3after = data(missing_ind(i,1),6);
                temp_4after = data(missing_ind(i,1),7);
                result(i) = head3(temp_2before, temp_1before, temp_1after, temp_2after,temp_3after, temp_4after);
            else if missing_ind(i,2) == 4
                    4
                    temp_3before = data(missing_ind(i,1),1);
                    temp_2before = data(missing_ind(i,1),2);
                    temp_1before = data(missing_ind(i,1),3);
                    temp_1after = data(missing_ind(i,1),5);
                    temp_2after = data(missing_ind(i,1),6);
                    temp_3after = data(missing_ind(i,1),7);
                    temp_4after = data(missing_ind(i,1),8);
                    result(i) = head4(temp_3before, temp_2before, temp_1before, temp_1after, temp_2after,temp_3after, temp_4after);
                else if missing_ind(i,2) == 100
                        100
                        temp_4before = data(missing_ind(i,1),96);
                        temp_3before = data(missing_ind(i,1),97);
                        temp_2before = data(missing_ind(i,1),98);
                        temp_1before = data(missing_ind(i,1),99);
                        result(i) = tail1(temp_4before, temp_3before, temp_2before, temp_1before);
                    else if missing_ind(i,2) == 99
                            99
                            temp_4before = data(missing_ind(i,1),95);
                            temp_3before = data(missing_ind(i,1),96);
                            temp_2before = data(missing_ind(i,1),97);
                            temp_1before = data(missing_ind(i,1),98);
                            temp_1after = data(missing_ind(i,1),100);
                            result(i) = tail2(temp_4before, temp_3before, temp_2before, temp_1before,temp_1after);
                        else if missing_ind(i,2) == 98
                                98
                                temp_4before = data(missing_ind(i,1),94);
                                temp_3before = data(missing_ind(i,1),95);
                                temp_2before = data(missing_ind(i,1),96);
                                temp_1before = data(missing_ind(i,1),97);
                                temp_1after = data(missing_ind(i,1),99);
                                temp_2after = data(missing_ind(i,1),100);
                                result(i) = tail3(temp_4before, temp_3before, temp_2before, temp_1before,temp_1after ,temp_2after);
                            else if missing_ind(i,2) == 97
                                    97
                                    temp_4before = data(missing_ind(i,1),93);
                                    temp_3before = data(missing_ind(i,1),94);
                                    temp_2before = data(missing_ind(i,1),95);
                                    temp_1before = data(missing_ind(i,1),96);
                                    temp_1after = data(missing_ind(i,1),98);
                                    temp_2after = data(missing_ind(i,1),99);
                                    temp_3after = data(missing_ind(i,1),100);
                                    result(i) = tail4(temp_4before, temp_3before, temp_2before, temp_1before,temp_1after ,temp_2after ,temp_3after);
                                else
                                    50
                                    temp_4before = data(missing_ind(i,1),missing_ind(i,2)-4);
                                    temp_3before = data(missing_ind(i,1),missing_ind(i,2)-3);
                                    temp_2before = data(missing_ind(i,1),missing_ind(i,2)-2);
                                    temp_1before = data(missing_ind(i,1),missing_ind(i,2)-1);
                                    temp_1after = data(missing_ind(i,1),missing_ind(i,2)+1);
                                    temp_2after = data(missing_ind(i,1),missing_ind(i,2)+2);
                                    temp_3after = data(missing_ind(i,1),missing_ind(i,2)+3);
                                    temp_4after = data(missing_ind(i,1),missing_ind(i,2)+4);
                                    result(i) = maxllh(temp_4before, temp_3before,temp_2before, temp_1before,temp_1after, temp_2after,temp_3after, temp_4after);
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end


                




answer(:,1) = 101:1000;
answer(:,2) = zeros(900,1)
for i = 1:missing_num
    answer(missing_ind(i,1)-100,2) = result(i);
end

csvwrite('answer.csv',answer);