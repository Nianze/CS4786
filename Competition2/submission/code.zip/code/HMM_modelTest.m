clear all
data_full=xlsread('fillindata.xls');
data=data_full(1:100,:);

%% test test the prediction accuracy with the training data. from 81-100 seq.
O=5;
StateOpt=11;% %%%change the state you want to test in each time you run the model%%%%
max_iter=100;
prior1 = normalise(rand(StateOpt,1));
transmat1 = mk_stochastic(rand(StateOpt,StateOpt));
obsmat1 = mk_stochastic(rand(StateOpt,O));
[LL, prior, transmat, obsmat] = dhmm_em(data(1:100,:), prior1, transmat1, obsmat1, 'max_iter', max_iter);



% test the prediction
LKH=zeros(20,5);
index=zeros(20,2);
test=zeros(20,1);
r=zeros(20,1);
obs=zeros(20,1);
data_ori=data;

N=1000;
X=zeros(N,1);
s=zeros(N,1);
for n=1:N
    s(n)=0;
    for i=1:20
        r(i)=randi(100); % ramdomly pick one position
        obs(i)=data(80+i,r(i)); % the value of observe emission
        for mis=1:5
            data(80+i,r(i))=mis;
            LKH(i,mis)=dhmm_logprob(data(80+i,:), prior, transmat, obsmat);
            data=data_ori;

        end
        
        [index(i,1),index(i,2)]=max(LKH(i,:));
        test(i)=index(i,2);
        if test(i)==obs(i)
            s(n)=s(n)+1;
        end
        
    end
    
    X(n)=s(n)/20;
    
end

%% find the confidence interval
prob=mean(X);
s=sqrt(sum((X-prob).^2)/(N-1));
z=1.96;
intv=[prob-z*s/sqrt(N),prob+z*s/sqrt(N)];

